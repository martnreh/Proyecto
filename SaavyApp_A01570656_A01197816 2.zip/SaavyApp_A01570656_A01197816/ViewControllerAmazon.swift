//
//  ViewControllerAmazon.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/6/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerAmazon: UIViewController {
    
    
    @IBOutlet var btnamazon: UIButton!
    

    @IBOutlet var img: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnamazon.layer.cornerRadius = 10.0
        btnamazon.layer.masksToBounds = true
        img.image = #imageLiteral(resourceName: "amazon")
        img.layer.cornerRadius = 10.0
        img.layer.masksToBounds = true
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    @IBAction func btnAmazonbutton(_ sender: Any) {
       UIApplication.shared.open(URL(string: "https://www.amazon.com.mx/")! as URL, options: [:], completionHandler: nil)
    }
    

}
