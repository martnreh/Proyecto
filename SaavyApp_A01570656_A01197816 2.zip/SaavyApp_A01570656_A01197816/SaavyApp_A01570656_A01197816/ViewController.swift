//
//  ViewController.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var lblSaavy: UILabel!
    
    
    @IBOutlet var btnLogo: UIButton!
    @IBAction func btnLogo(_ sender: UIButton) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    btnLogo.layer.cornerRadius = 10.0
    btnLogo.layer.masksToBounds = true
        
        lblSaavy.layer.cornerRadius = 10.0
        lblSaavy.layer.masksToBounds = true
        
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

