//
//  ViewControllerProfile.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerProfile: UIViewController {
    
    @IBOutlet var imgProfile: UIImageView!
    
    @IBOutlet var txtGender: UITextField!
    
    @IBOutlet var lblUsername: UILabel!
    
    @IBOutlet var txtMonthlyIncome: UITextField!
    
    @IBOutlet var txtMonths: UITextField!
    @IBOutlet var lblEmail: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

      imgProfile.image = UIImage(named: "users")
        
        if (user == "0" ){
            lblUsername.text = String(Usernames[0])
            lblEmail.text = String(Emails[0])
        }
        
        if (user == "1" ){
             lblUsername.text = String(Usernames[1])
            lblEmail.text = String(Emails[1])
           
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func `switch`(_ sender: UISwitch) {
        
        
        if (sender.isOn == true && txtGender.text == "Male"){
            print("switch on")
            imgProfile.image = UIImage(named: "man")
           
            
        }
        else if (sender.isOn == true && txtGender.text == "Female"){
            print("switch on")
            imgProfile.image = UIImage(named: "girl")
            
            
        }
        else if (sender.isOn == false && txtGender.text != "Female" || txtGender.text != "Male"){
            print("switch on")
            imgProfile.image = UIImage(named: "users")
            
            
        }
        else{
            print("switch off")
            
           
             imgProfile.image = UIImage(named: "Blank")
            }
           
            
        
        }
    
    
    @IBAction func btnBack(_ sender: UIButton) {
        
        
        if (user == "1" ){
            print("income")
            Income = txtMonthlyIncome.text!
            Months = String(txtMonths.text!)
            
        }
        
        else{
            print("income else")
            IncomeTest = txtMonthlyIncome.text!
            MonthsTest = String(txtMonths.text!)
            Income = txtMonthlyIncome.text!
            Months = String(txtMonths.text!)
        }
        
      }
    
    
    
   
    
    
    
 
    }
    


