//
//  ViewControllerExpenses.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

var daystest = 1
var days = 1

class ViewControllerExpenses: UIViewController {
    
    
    @IBOutlet var txtExpenseProduct: UITextField!
    
    @IBOutlet var txtExpenseCost: UITextField!
    
    
    @IBOutlet var btnmenos: UIButton!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnmenos.layer.masksToBounds = true
        
        btnmenos.layer.cornerRadius = 10.0
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    
    @IBAction func btnMinus(_ sender: UIButton) {
        
        if (user == "0" ){
           
            
          BoughtTest +=  [(txtExpenseProduct.text!)]
            
            DaysTest += [String(daystest)]
            GastoTest = GastoTest + Int(txtExpenseCost.text!)!
            ExpensesTest  = ExpensesTest + Int(txtExpenseCost.text!)!
            
        }
        
        if (user == "1" ){
         
            
            Bought += [(txtExpenseProduct.text!)]
          
            Days += [String(days)]
            Gasto = Gasto + Int(txtExpenseCost.text!)!
            Expenses  = Expenses + Int(txtExpenseCost.text!)!
            
        }
        
    }
    
    
   
        
    
    }
    

 

