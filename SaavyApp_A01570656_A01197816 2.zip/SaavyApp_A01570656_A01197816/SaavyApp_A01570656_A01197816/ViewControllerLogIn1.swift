//
//  ViewControllerLogIn1.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerLogIn1: UIViewController {
    
    

    @IBOutlet var btnlogin: UIButton!
    
    @IBOutlet var btnCheck: UIButton!
    
    
    @IBOutlet var txtEmail: UITextField!
    
    
    @IBOutlet var txtPassword: UITextField!
    
    
    @IBOutlet var lblAnswer: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnlogin.layer.cornerRadius = 10.0
        btnlogin.layer.masksToBounds = true
        btnCheck.layer.cornerRadius = 10.0
        btnCheck.layer.masksToBounds = true

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

    @IBAction func btnCheck1(_ sender: UIButton) {
        
        
        let email1 = String(txtEmail.text!)
        let pass1 = String(txtPassword.text!)
        let ind_em = Emails.index(of: email1)
        let ind_pa = Passwords.index(of: pass1)
        
        
        
        if (Emails.contains(email1) && Passwords.contains(pass1) && (ind_em == ind_pa) && String(Emails[0]) == String(txtEmail.text!)){
            lblAnswer.text = "Hi, Welcome back " + String(Usernames[ind_em!])
            user = "0"
            print ("user0")
            
           
        }
        else {
            lblAnswer.text  = "Account does not exists"
        }
        
        if (Emails.contains(email1) && Passwords.contains(pass1) && (ind_em == ind_pa) && String(Emails[0]) != (txtEmail.text!)){
            lblAnswer.text = "Hi, Welcome back " + String(Usernames[ind_em!])
            user = "1"
            print ("user1")
            
            
        }
            
        if (Emails.contains(email1) && (ind_em != ind_pa) )   {
            
            lblAnswer.text  = email1 + "´s password is incorrect"
        }
            
            
            
      
        
    }
    
    
    @IBAction func btnLogin(_ sender: UIButton) {
        
        
    }
    
    }
    


