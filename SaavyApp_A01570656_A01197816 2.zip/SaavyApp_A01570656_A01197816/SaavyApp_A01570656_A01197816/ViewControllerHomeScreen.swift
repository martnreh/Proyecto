//
//  ViewControllerHomeScreen.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit


var Emails = ["a01570656@itesm.mx"]
var Passwords = ["1234"]
var Usernames = ["Adrian Martin"]
var user = ""

var ProductsTest = ["Iphone X","House","Trip to London"]
var PricesTest = ["27,000","4000000","85000"]

var ImagesTest = [UIImage](arrayLiteral: #imageLiteral(resourceName: "img5"), #imageLiteral(resourceName: "img1"),#imageLiteral(resourceName: "img3"))
var DaysTest = [""]
var BoughtTest = [""]
var ExpensesTest = 0
var IncomeTest = "0"
var MonthsTest = "1"
var GastoTest = 0
var usuario0gasta = 0



var Products = [""]
var Prices = [""]
var Images = [UIImage] ()
var Days = [""]
var Bought = [""]
var Expenses = 0
var Income = "0"
var Months = "1"
var Gasto = 0
var usuario1gasta = 0




var imageselected = #imageLiteral(resourceName: "img1")
var nameselected = ""
var priceselected = ""





class ViewControllerHomeScreen: UIViewController {
    
    @IBOutlet var imgProduct: UIImageView!
    @IBOutlet var lblback: UILabel!
    
    
    @IBOutlet var lblProductName: UILabel!
    @IBOutlet var lblProductPrice: UILabel!
    @IBOutlet var SegmentUser: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblback.layer.cornerRadius = 10.0
        lblback.layer.masksToBounds = true
        imgProduct.layer.cornerRadius = 10.0
        imgProduct.layer.masksToBounds = true
        
        if (user == "1" && SegmentUser.selectedSegmentIndex == 0){
            lblProductName.text = Products[1]
            lblProductPrice.text = "$" + Prices[1]
            imgProduct.image = Images[0]
            nameselected = Products[1]
            priceselected = Prices[1]
            imageselected = Images[0]
            
        }
        
        if (user == "0" && SegmentUser.selectedSegmentIndex == 0){
            lblProductName.text = ProductsTest[0]
            lblProductPrice.text = "$" + PricesTest[0]
            imgProduct.image = ImagesTest[0]
            nameselected = ProductsTest[0]
            priceselected = PricesTest[0]
            imageselected = ImagesTest[0]
        }
        
       
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    @IBAction func SegmentUser(_ sender: UISegmentedControl) {
        
        if (user == "0" && SegmentUser.selectedSegmentIndex == 0){
            lblProductName.text = ProductsTest[0]
            lblProductPrice.text = "$" + PricesTest[0]
            imgProduct.image = ImagesTest[0]
            nameselected = ProductsTest[0]
            priceselected = PricesTest[0]
            imageselected = ImagesTest[0]
            
        }
        
        else if (user == "0" && SegmentUser.selectedSegmentIndex == 1){
            lblProductName.text = ProductsTest[1]
            lblProductPrice.text = "$" + PricesTest[1]
           imgProduct.image = ImagesTest[1]
            nameselected = ProductsTest[1]
            priceselected = PricesTest[1]
            imageselected = ImagesTest[1]
          
        }
        
        else if (user == "0" && SegmentUser.selectedSegmentIndex == 2){
            lblProductName.text = ProductsTest[2]
            lblProductPrice.text = "$" + PricesTest[2]
            imgProduct.image = ImagesTest[2]
            nameselected = ProductsTest[2]
            priceselected = PricesTest[2]
            imageselected = ImagesTest[2]
            
        }
        
        else if (user == "1" && SegmentUser.selectedSegmentIndex == 0){
            lblProductName.text = Products[1]
            lblProductPrice.text = "$" + Prices[1]
            imgProduct.image = Images[0]
            nameselected = Products[1]
            priceselected = Prices[1]
            imageselected = Images[0]
            
        }
        
        else if (user == "1" && SegmentUser.selectedSegmentIndex == 1){
            lblProductName.text = Products[2]
            lblProductPrice.text = "$" + Prices[2]
            imgProduct.image = Images[1]
            nameselected = Products[2]
            priceselected = Prices[2]
            imageselected = Images[1]
          
        }
        else if (user == "1" && SegmentUser.selectedSegmentIndex == 2){
            lblProductName.text = Products[3]
            lblProductPrice.text = "$" + Prices[3]
             imgProduct.image = Images[2]
            nameselected = Products[3]
            priceselected = Prices[3]
            imageselected = Images[2]
            
        }
        
      
        
    }
    
   

}
