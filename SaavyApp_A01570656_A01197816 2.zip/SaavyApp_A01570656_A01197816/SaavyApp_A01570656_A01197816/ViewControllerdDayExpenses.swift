//
//  ViewControllerdDayExpenses.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerdDayExpenses: UIViewController {

    
    @IBOutlet var lblGastotal: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(user == "0"){
            
        
            lblGastotal.text = "$" + String(ExpensesTest)
   
        }
        if(user == "1"){
            
            
            lblGastotal.text = "$" + String(Expenses)
            
        }
        

        
    }
        
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

   

}
