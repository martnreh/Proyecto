//
//  ViewControllerCreateAccount.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerCreateAccount: UIViewController {
    
    
    
    
    @IBOutlet var btnRegister: UIButton!
    
    
    @IBOutlet var txtName: UITextField!
    
    
    @IBOutlet var txtEmail: UITextField!
    
    
    @IBOutlet var txtPassword: UITextField!
    
    
    @IBOutlet var txtConfirmPassword: UITextField!
    
    
    @IBOutlet var lblAnswer: UILabel!
    
    @IBOutlet var btnCheck: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnRegister.layer.cornerRadius = 10.0
        btnRegister.layer.masksToBounds = true
        btnCheck.layer.cornerRadius = 10.0
        btnCheck.layer.masksToBounds = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    
        
    }
    

    @IBAction func btnCheck1(_ sender: UIButton) {
        let emailregister = String(txtEmail.text!)
        let nameregister = String(txtName.text!)
        let passregister = String(txtPassword.text!)
        let passregister2 = String(txtConfirmPassword.text!)
        
        print(passregister)
        print(passregister2)
        
        if (passregister != passregister2){
            print("1")
            
            lblAnswer.text = "Retry your password"
        }
            
        else  if (Emails.contains(emailregister) && passregister == passregister2) {
            print("2")
            lblAnswer.text = "Email account already used"
            
            
            
        }
            
        else  if (Emails.contains(emailregister) && passregister != passregister2) {
            print("2")
            lblAnswer.text = "Email account already used"
            
            
            
        }
            
        else {
            print("3")
            lblAnswer.text = nameregister + "´s account was successfully created"
            
            
            
            
            
            Emails += [(txtEmail.text!)]
            Passwords += [(txtPassword.text!)]
            Usernames += [(txtName.text!)]
            
            
            
        }
    }
    
    @IBAction func btnRegister(_ sender: UIButton) {
        user = "1"
        print("user1")
    }
    

}
