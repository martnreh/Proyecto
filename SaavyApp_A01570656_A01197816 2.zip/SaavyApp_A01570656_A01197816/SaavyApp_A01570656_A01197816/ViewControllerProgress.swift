//
//  ViewControllerProgress.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerProgress: UIViewController {

    
    @IBOutlet var lblStart: UILabel!
    
    
    @IBOutlet var lbldiasexpensesuser: UILabel!
    @IBOutlet var MonthlyExpenses: UITextField!
    
    @IBOutlet var lblMonths: UILabel!
    
    @IBOutlet var img: UIImageView!
    
    @IBOutlet var lblproduct: UILabel!
    @IBOutlet var lblprice: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblprice.text = priceselected
        lblproduct.text = nameselected
        
        
        
        if (user == "1" ){
            
         
            
            
            
           
            lblStart.text = "Starting from: $" +  Income + " pesos per month"
            lblMonths.text = "Goal: Buy it in " + Months + " months"
            img.image = imageselected
            lblproduct.text = String(nameselected )
            lblprice.text = String(priceselected)
         
        }
        
    if (user == "0"){
        
        
        
        
        
        lblStart.text = "Starting from: $" +  IncomeTest + " pesos per month"
        
        lblMonths.text = "Goal: Buy it in " + MonthsTest + " months"
        img.image = imageselected
        lblproduct.text = String(nameselected )
        lblprice.text = String(priceselected)
        
        
        
        
        }
        

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    @IBAction func btnCalculate(_ sender: UIButton) {
        usuario0gasta = Int(MonthlyExpenses.text!)!
        usuario1gasta = Int(MonthlyExpenses.text!)!
        
        
        let precio = Int(lblprice.text!)
        
        
      
       
       
        
        
        if (user == "1" ){
            let step1 = (Int(Income)! - usuario1gasta)
            let step2 = precio! - (step1 * Int(Months)!)
            let months30 =  Int(Months)! * 30
            
            let dineropordiatest1 = step2 / months30
            
              lbldiasexpensesuser.text = String(dineropordiatest1)
            lblStart.text = "Starting from: $" +  Income + " pesos per month"
            lblMonths.text = "Goal: Buy it in " + Months + " month(s)"
            img.image = imageselected
            lblproduct.text = String(nameselected )
            lblprice.text = String(priceselected)
             lbldiasexpensesuser.text = "If you save $" + String(dineropordiatest1) + "  pesos per day for " + String(Months) + " months, you will be able to buy your product in the desired time"
        }
        
        if (user == "0"){
             let precio = Int(lblprice.text!)
            
            let step1test = (Int(IncomeTest)! - usuario0gasta)
            let step2test = precio! - (step1test * Int(MonthsTest)!)
            let months30test =  Int(Months)! * 30
            
            let dineropordiatest0 = step2test / months30test
            
            
            lbldiasexpensesuser.text = String(dineropordiatest0)
            lblStart.text = "Starting from: $" +  IncomeTest + " pesos per month"
            
            lblMonths.text = "Goal: Buy it in " + MonthsTest + " month(s)"
            img.image = imageselected
            lblproduct.text = String(nameselected )
            lblprice.text = String(priceselected)
            
            lbldiasexpensesuser.text = "If you save $" + String(dineropordiatest0) + " pesos per day for " + String(MonthsTest) + " months you will be able to buy your desired product in the desired time."
            
            
        }

    }
    
  

}
