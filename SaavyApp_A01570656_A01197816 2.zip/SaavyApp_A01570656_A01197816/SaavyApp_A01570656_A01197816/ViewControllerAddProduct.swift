//
//  ViewControllerAddProduct.swift
//  SaavyApp_A01570656_A01197816
//
//  Created by Adrian Martin Hernandez  on 5/5/19.
//  Copyright © 2019 Adrian Martin Hernandez . All rights reserved.
//

import UIKit

class ViewControllerAddProduct: UIViewController {
    
    
    @IBOutlet var txtAddProduct: UITextField!
    @IBOutlet var txtAddPrice: UITextField!
    @IBOutlet var lblImageNumber: UILabel!
    
    @IBOutlet var lblAlert: UILabel!
    
    @IBAction func btn1(_ sender: UIButton) {
        lblImageNumber.text = "1"
    }
    @IBAction func btn2(_ sender: UIButton) {
        lblImageNumber.text = "2"
    }
    @IBAction func btn3(_ sender: UIButton) {
        lblImageNumber.text = "3"
    }
    @IBAction func btn4(_ sender: UIButton) {
        lblImageNumber.text = "4"
    }
    @IBAction func btn5(_ sender: UIButton) {
        lblImageNumber.text = "5"
    }
    @IBAction func btn6(_ sender: UIButton) {
        lblImageNumber.text = "6"
    }
    @IBAction func btn7(_ sender: UIButton) {
        lblImageNumber.text = "7"
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (ProductsTest.count >= 3 || Products.count >= 3)
        {
            let myAlert = UIAlertController(title:"Sorry :(", message: "You can only have 3 products as your main objectives", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "Got it", style: .default)
            myAlert.addAction(okButton)
            present(myAlert,animated:true)
       
            }
        else{
            print("no alert")
        }
        
    }
        

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
  
    }
    
    

    @IBAction func btnAddProduct(_ sender: UIButton) {
        let number = Int(lblImageNumber.text!)!
        let size0 = ProductsTest.count
        let size1 = Products.count
        
        if (size0 > 4 || size1 > 4){
            let myAlert = UIAlertController(title:"Sorry :(", message: "You can only have 3 products as your main objectives", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "Got it", style: .default)
            myAlert.addAction(okButton)
            present(myAlert,animated:true)
            
            
            print("error with adding images to product")
            lblAlert.text = "You can only have 3 products as your main objectives"
              print("salio el if")
            
        }
        
        if (user == "0" && size0 <= 3  && number == 1){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img1")!)
        }
        else if (user == "0" && size0 <= 3  && number == 2){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img2")!)
        }
       else  if (user == "0" && size0 <= 3  && number == 3){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img3")!)
        }
       else  if (user == "0" && size0 <= 3  && number == 4){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img4")!)
        }
        else if (user == "0" && size0 <= 3  && number == 5){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img5")!)
        }
       else if (user == "0" && size0 <= 3  && number == 6){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img6")!)
        }
        else if (user == "0" && size0 <= 3  && number == 7){
            ProductsTest += [(txtAddProduct.text!)]
            PricesTest += [(txtAddPrice.text!)]
            ImagesTest.append(UIImage(named: "img7")!)
        }
            
      else if (user == "1" && size1 <= 3 && number == 1){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img1")!)
            
    }
        else if (user == "1" && size1 <= 3 && number == 2){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img2")!)
        }
        else if (user == "1" && size1 <= 3 && number == 3){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img3")!)
        }
        else if (user == "1" && size1 <= 3 && number == 4){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img4")!)
        }
        else if (user == "1" && size1 <= 3 && number == 5){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img5")!)
        }
        
        else if (user == "1" && size1 <= 3 && number == 6){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img6")!)
        }
        else if (user == "1" && size1 <= 3 && number == 7){
            Products += [(txtAddProduct.text!)]
            Prices += [(txtAddPrice.text!)]
            Images.append(UIImage(named: "img7")!)
        }
            
            
            
        
        else{
            
            print("salio el else")
            
            let myAlert = UIAlertController(title:"Sorry :(", message: "You can only have 3 products as your main objectives", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "Got it", style: .default)
            myAlert.addAction(okButton)
            present(myAlert,animated:true)
                
                
                print("error with adding images to product")
                lblAlert.text = "You can only have 3 products as your main objectives"
                
            }
            
            
        }
        
        
        }
        
       
        
      
        
        
    
   



